Symulacja grypy

Uruchamiamy korzystając z terminala ustawionego na ścieżce z plikiem Miss.jar poleceniem:

java -jar Miss.jar [ścieżka log'a, ścieżka obrazu]

W folderze z Miss.jar powinien się znaleźć plik sim.log oraz img1.png - są to domyślne pliki uruchamiane wraz z aplikacja, jednak można je zastąpić podając ścieżki do plików jako argumenty programu.

Plik log powinien być to pusty plik - zapisywane w nim będą statystyki z przebiegu symulacji
Plik obrazu - plik o rozszerzeniu .png zawierający biało-czarny obraz, gdzie czarne elementy są uznawane za punkty zainteresowania (Points of Interest)

Plik simulation.mp4 pokazuje przykładowe korzystanie z programu

Plik Raport.pdf zawiera raport z projektu.

Folder src zawiera kody programu symulacji.

Wykonali:
Dawid Bartkowski, Tomasz Adamski, Michał Kupiec
